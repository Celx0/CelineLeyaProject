<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *'); 
header('Access-Control-Allow-Methods: POST, GET, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

$servername = "fdb1030.awardspace.net";
$username = "4508249_celine";
$password = "mnbvcelinE45_wq2";
$dbname = "4508249_celine";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    echo json_encode(['status' => 'error', 'message' => 'Connection failed: ' . $conn->connect_error]);
    exit();
}

$data = json_decode(file_get_contents("php://input"), true);

file_put_contents('debug_log.txt', print_r($data, true));

if ($data && is_array($data)) {
    $name = isset($data['name']) ? $conn->real_escape_string($data['name']) : '';
    $phone = isset($data['phone']) ? $conn->real_escape_string($data['phone']) : '';
    $country = isset($data['country']) ? $conn->real_escape_string($data['country']) : '';
    $city = isset($data['city']) ? $conn->real_escape_string($data['city']) : '';
    $street = isset($data['street']) ? $conn->real_escape_string($data['street']) : '';
    $building = isset($data['building']) ? $conn->real_escape_string($data['building']) : '';
    $payment_method = isset($data['payment_method']) ? $conn->real_escape_string($data['payment_method']) : 'Cash'; 
    $total_price = isset($data['total_price']) ? $conn->real_escape_string($data['total_price']) : 0.00;
    $total_item_count = isset($data['total_item_count']) ? $conn->real_escape_string($data['total_item_count']) : 0;
    $date = date("Y-m-d H:i:s"); 

    $sql = "INSERT INTO orders (name, phone, country, city, street, building, payment_method, total_price, total_item_count, order_date) 
            VALUES ('$name', '$phone', '$country', '$city', '$street', '$building', '$payment_method', '$total_price', '$total_item_count', '$date')";

    if ($conn->query($sql) === TRUE) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => $conn->error]);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'No data received']);
}

$conn->close();
?>


